(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['percolate:momentum-iron-router'] = {};

})();

//# sourceMappingURL=percolate_momentum-iron-router.js.map
